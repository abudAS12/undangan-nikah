<!doctype html>
<html class="no-js" lang="zxx">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Website Undangan Pernikahan - UNDGN</title>
        <meta name="description" content="Sebarin Undangan Sepuasnya, pakai Undangan Website lebih hemat, praktis & cepat! Buat undangan nikah online dengan mudah. Undangan Pernikahan Online dikemas dalam bentuk web dengan desain yang kreatif serta fitur yang menarik">
        <meta name="keywords" content="undangan, undangan nikah, undangan pernikahan digital, undangan pernikahan online, undangan nikah digital, undangan nikah online, undangan nikah web, undangan nikah unik">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="facebook-domain-verification" content="jmc7oayup3koacfyjer3t4r5z4sga7" />
        <link rel="apple-touch-icon" sizes="57x57" href="https://undgn.id/img/favicon/apple-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="https://undgn.id/img/favicon/apple-icon-60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="https://undgn.id/img/favicon/apple-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="https://undgn.id/img/favicon/apple-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="https://undgn.id/img/favicon/apple-icon-114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="https://undgn.id/img/favicon/apple-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="https://undgn.id/img/favicon/apple-icon-144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="https://undgn.id/img/favicon/apple-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="180x180" href="https://undgn.id/img/favicon/apple-icon-180x180.png">
        <link rel="icon" type="image/png" sizes="192x192"  href="https://undgn.id/img/favicon/android-icon-192x192.png">
        <link rel="icon" type="image/png" sizes="32x32" href="https://undgn.id/img/favicon/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="96x96" href="https://undgn.id/img/favicon/favicon-96x96.png">
        <link rel="icon" type="image/png" sizes="16x16" href="https://undgn.id/img/favicon/favicon-16x16.png">
        <link rel="manifest" href="https://undgn.id/img/favicon/manifest.json">
        <meta name="msapplication-TileColor" content="#ffffff">
        <meta name="msapplication-TileImage" content="https://undgn.id/img/favicon/ms-icon-144x144.png">
        <meta name="theme-color" content="#ffffff">
        <meta name="facebook-domain-verification" content="tb3knbau4me4uvmorre4et0axgxpdp" />
        <style type="text/css">
        html, body {
            height: 100%;
            font-family: 'Open Sans', sans-serif;
        }
        body {
            overflow: hidden;
        }
        #preloader {
            position: fixed;
            top:0;
            left:0;
            right:0;
            bottom:0;
            background-color:#fff3e2;
            z-index:9999999;
            color: #FFFFFF;
        }
        .preload-body {
            width: 100%;
            height: 100%;
            top: 50%;
            margin: 0 auto;
            position: relative;
        }
        </style>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" href="https://undgn.id/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://undgn.id/css/animate-headline.css">
        <link rel="stylesheet" href="https://undgn.id/css/venobox.css">
        <link rel="stylesheet" href="https://undgn.id/css/slick.css">
        <link rel="stylesheet" href="https://undgn.id/css/animate.css">
        <link rel="stylesheet" href="https://undgn.id/css/normalize.css">
        <link rel="stylesheet" href="https://undgn.id/css/main.css">
        <link rel="stylesheet" href="https://undgn.id/css/responsive.css">
        <script src="https://undgn.id/js/vendor/modernizr-2.8.3.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://undgn.id/css/style17.css">
        <script>
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};
        if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
        n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t,s)}(window, document,'script',
        'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '1793316170865698');
        fbq('track', 'PageView');
        fbq('track', 'ViewContent');
        </script>
        <noscript><img height="1" width="1" style="display:none"
        src="https://www.facebook.com/tr?id=1793316170865698&ev=PageView&noscript=1"
        /></noscript>
        <!-- Google Tag Manager -->
        <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-P4XKXMZM');</script>
        <!-- End Google Tag Manager -->
    </head>
    <body>
        <!-- Google Tag Manager (noscript) -->
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P4XKXMZM"
        height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
        <!-- End Google Tag Manager (noscript) -->
        <div id="preloader">
          <div class="preload-body">
              <div id="base">
                <div class="f11"></div>
                <div class="f12"></div>
                <div class="f13"></div>
                <div class="f14"></div>
              </div>
          </div>
        </div>
        <div class="wrapper">
            <header class="header-area">
                <!-- Menu Area
                ============================================ -->
                <div id="main-menu" class="sticker" style="border: none;">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 col-xs-12">
                                <div class="logo float-left navbar-header">
                                    <a class="navbar-brand" href="https://undgn.id"><img src="https://undgn.id/img/logo.webp" width="150" alt=""></a>
                                    <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#main-menu-2">
                                        <i class="fa fa-bars menu-open"></i>
                                        <i class="fa fa-times menu-close"></i>
                                    </button>
                                </div>
                                <div class="main-menu float-right collapse navbar-collapse" id="main-menu-2">
                                    <nav>
                                        <ul class="menu one-page">
                                            <li class="active"><a href="#home-area">Home</a></li>
                                            <li><a href="#feature-area">Fitur</a></li>
                                            <li><a href="#katalog-area">Tema</a></li>
                                            <li><a href="#contact-area">Kontak</a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- home area -->
            <div id="home-area" style="margin-top: 120px;">
                <div class="pb-60">
                    <div class="container">
                        <div class="row text-left">
                            <div class="stage">
                                <div class="col-md-8 top-text text-center pt-60 text-home">
                                    <div class="slider-text">
                                        <h1>Undangan Website</h1>
                                        <p>Sekarang saatnya beralih ke Undangan Website Digital.</p>
                                        <p class="cd-headline clip">
                                            <span class="cd-words-wrapper">
                                                <b class="is-visible" style="font-weight: 500;">Bikinnya cepat  </b>
                                                <b style="font-weight: 500;">Lebih hemat</b>
                                                <b style="font-weight: 500;">Desain kekinian</b>
                                                <b style="font-weight: 500;">Sebarin sepuasnya!</b>
                                            </span>
                                        </p>
                                        <br>
                                        <div class="button-set" style="margin-top: 0; margin-bottom: 30px;">
                                            <a class="button" href="#katalog-area" style="margin: 0;">
                                                Lihat Katalog
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <img src="https://undgn.id/img/banner.webp" class="col-md-4 box bounce-2 pt-30" alt="" >
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- fitur area -->
            <div id="feature-area">
                <div class="pb-60">
                    <div class="container">
                        <div class="row text-center text-feature">
                            <div class="boxs col-4 col-sm-3 col-md-2 my-3 boxs-feature">
                                <div class="single-features-list">
                                    <div class="feature-list-icon">
                                        <i class="fa fa-hourglass-half" aria-hidden="true"></i>
                                    </div>
                                    <div class="feature-list-text">
                                        <p>Proses pengerjaan sangat cepat ± 1 hari</p>
                                    </div>
                                </div>
                            </div>
                            <div class="boxs col-4 col-sm-3 col-md-2 my-3 boxs-feature">
                                <div class="single-features-list">
                                    <div class="feature-list-icon">
                                        <i class="fa fa-phone" aria-hidden="true"></i>
                                    </div>
                                    <div class="feature-list-text">
                                        <p>Full support kamu kapanpun</p>
                                    </div>
                                </div>
                            </div>
                            <div class="boxs col-4 col-sm-3 col-md-2 my-3 boxs-feature">
                                <div class="single-features-list">
                                    <div class="feature-list-icon">
                                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                    </div>
                                    <div class="feature-list-text">
                                        <p>Bebas revisi data undangan sepuasnya</p>
                                    </div>
                                </div>
                            </div>
                            <div class="boxs col-4 col-sm-3 col-md-2 my-3 boxs-feature">
                                <div class="single-features-list">
                                    <div class="feature-list-icon">
                                        <i class="fa fa-music" aria-hidden="true"></i>
                                    </div>
                                    <div class="feature-list-text">
                                        <p>Pilih sendiri backsound kesukaanmu</p>
                                    </div>
                                </div>  
                            </div>
                            <div class="boxs col-4 col-sm-3 col-md-2 my-3 boxs-feature">
                                <div class="single-features-list">
                                    <div class="feature-list-icon">
                                        <i class="fa fa-envelope" aria-hidden="true"></i>
                                    </div>
                                    <div class="feature-list-text">
                                        <p>Amplop Digital untuk pengantin</p>
                                    </div>
                                </div>
                            </div>
                            <div class="boxs col-4 col-sm-3 col-md-2 my-3 boxs-feature">
                                <div class="single-features-list res-features">
                                    <div class="feature-list-icon">
                                        <i class="fa fa-user-plus" aria-hidden="true"></i>
                                    </div>
                                    <div class="feature-list-text">
                                        <p>Unlimited nama tamu undangan</p>
                                    </div>
                                </div> 
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
            <!-- katalog area -->
            <div id="katalog-area">
                <div class="pb-120">
                    <div class="container">
                        <div class="row text-center">
                            <h2>Katalog Undangan</h2>
                            <p>Silakan klik gambar dibawah ini untuk melihat contoh demo undangan</p>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-1/" target="_blank" >
                                    <div class="title-theme">Tema 1</div>
                                    <img src="https://undgn.id/img/theme/1.jpg" alt="Tema 1" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema 1.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-2/" target="_blank" >
                                    <div class="title-theme">Tema 2</div>
                                    <img src="https://undgn.id/img/theme/2.jpg" alt="Tema 2" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema 2.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-3/" target="_blank" >
                                    <div class="title-theme">Tema 3</div>
                                    <img src="https://undgn.id/img/theme/3.jpg" alt="Tema 3" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema 3.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-4/" target="_blank" >
                                    <div class="title-theme">Tema 4</div>
                                    <img src="https://undgn.id/img/theme/4.jpg" alt="Tema 4" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema 4.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-5/" target="_blank" >
                                    <div class="title-theme">Tema 5</div>
                                    <img src="https://undgn.id/img/theme/5.jpg" alt="Tema 5" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema 5.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-6/" target="_blank" >
                                    <div class="title-theme">Tema 6</div>
                                    <img src="https://undgn.id/img/theme/6.jpg" alt="Tema 6" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema 6.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-7/" target="_blank" >
                                    <div class="title-theme">Tema 7</div>
                                    <img src="https://undgn.id/img/theme/7.jpg" alt="Tema 7" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema 7.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-8/" target="_blank" >
                                    <div class="title-theme">Tema 8</div>
                                    <img src="https://undgn.id/img/theme/8.jpg" alt="Tema 8" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema 8.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-9/" target="_blank" >
                                    <div class="title-theme">Tema 9</div>
                                    <img src="https://undgn.id/img/theme/9.jpg" alt="Tema 9" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema 9.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-10/" target="_blank" >
                                    <div class="title-theme">Tema 10</div>
                                    <img src="https://undgn.id/img/theme/10.jpg" alt="Tema 10" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema 10.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-11/" target="_blank" >
                                    <div class="title-theme">Tema 11</div>
                                    <img src="https://undgn.id/img/theme/11.jpg" alt="Tema 11" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema 11.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-12/" target="_blank" >
                                    <div class="title-theme">Tema 12</div>
                                    <img src="https://undgn.id/img/theme/12.jpg" alt="Tema 12" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema 12.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-13/" target="_blank" >
                                    <div class="title-theme">Tema 13</div>
                                    <img src="https://undgn.id/img/theme/13.jpg" alt="Tema 13" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema 13.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-14/" target="_blank" >
                                    <div class="title-theme">Tema 14</div>
                                    <img src="https://undgn.id/img/theme/14.jpg" alt="Tema 14" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema 14.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-15/" target="_blank" >
                                    <div class="title-theme">Tema 15</div>
                                    <img src="https://undgn.id/img/theme/15.jpg" alt="Tema 15" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema 15.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-16/" target="_blank" >
                                    <div class="title-theme">Tema 16</div>
                                    <img src="https://undgn.id/img/theme/16.jpg" alt="Tema 16" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema 16.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-17/" target="_blank" >
                                    <div class="title-theme">Tema 17</div>
                                    <img src="https://undgn.id/img/theme/17.jpg" alt="Tema 17" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema 17.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-adat-1/" target="_blank" >
                                    <div class="title-theme">Tema Adat 1</div>
                                    <img src="https://undgn.id/img/theme/adat_1.jpg" alt="Tema Adat 1" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema Adat 1.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                        <div class="boxs col-6 col-sm-3 col-md-2 my-3">
                                <a href="https://undgn.id/tema-adat-2/" target="_blank" >
                                    <div class="title-theme">Tema Adat 2</div>
                                    <img src="https://undgn.id/img/theme/adat_2.jpg" alt="Tema Adat 2" />
                                </a>
                                <div class="price-btn text-center my-3">
                                    <a class="button" style="padding: 5px 10px;" target="_blank" href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan%20dengan%20Tema Adat 2.%0AGimana%20caranya%20ya%3F"><span class="fa fa-shopping-cart" aria-hidden="true"></span>&nbsp;&nbsp;Pesan ini</a>
                                </div>
                            </div>
                                                    </div>
                    </div>
                </div>
            </div>
            <!-- warranty area -->
            <div class="pb-120">
                <div class="container">
                    <div class="about-bottom-left clearfix text-center">
                        <img class="pb-30" src="https://undgn.id/img/icon-img/guarantee.png" width="100">
                        <h3 style="font-size: 16px;">Garansi Uang Kembali 100%</h3>
                        <p style="font-size: 12px; line-height: unset;">Jika dalam waktu 7 hari kamu belum menerima link undangan website dari kami dan atau hasil akhir websitemu tidak sesuai dengan yang kamu harapkan. Kamu boleh mengajukan refund tanpa biaya dan potongan apapun.</p>                        
                        <img class="p-30" src="https://undgn.id/img/icon-img/secure.png">
                    </div>
                </div>
            </div>
            <!-- footer area -->
            <footer id="contact-area" class="footer-area pt-30">
                <div class="container">
                    <div class="col-md-12 text-center">
                        <div class="footer-all">
                            <div class="footer-text">
                                <p style="color: white;">
                                    Developed with <span style="color: red">&#10084;</span> by <a href="https://undgn.id" target="_blank">UNDGN</a>
                                    <br>
                                    © 2024 All right reserved.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- start scrollUp
            ============================================ -->
            <!-- div id="toTop">
                <i class="fa fa-chevron-up"></i>
            </div -->

            <a href="https://wa.me/6282136108904?text=Hai%2C%20saya%20mau%20order%20Website%20Undangan%20Pernikahan.%0AGimana%20caranya%20ya%3F" class="button-whatsapp" target="_blank">
            <i class="fa fa-whatsapp whatsapp"></i>
            </a>
        </div>
        
        
        <!-- jquery
        ============================================ -->        
        <script src="https://undgn.id/js/vendor/jquery-1.12.4.min.js"></script>
        <!-- bootstrap JS
        ============================================ -->        
        <script src="https://undgn.id/js/bootstrap.min.js"></script>
        <!-- ajax mails JS
        ============================================ -->
        <script src="https://undgn.id/js/ajax-mail.js"></script>
        <!-- plugins JS
        ============================================ -->        
        <script src="https://undgn.id/js/plugins.js"></script>
        <!-- google map api -->
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD_qDiT4MyM7IxaGPbQyLnMjVUsJck02N0"></script>
        <script>
            var myCenter=new google.maps.LatLng(30.249796, -97.754667);
            function initialize()
            {
                var mapProp = {
                    center:myCenter,
                    scrollwheel: false,
                    zoom:15,
                    mapTypeId:google.maps.MapTypeId.ROADMAP
                };
                var map=new google.maps.Map(document.getElementById("hastech"),mapProp);
                var marker=new google.maps.Marker({
                    position:myCenter,
                    animation:google.maps.Animation.BOUNCE,
                    icon:'img/map-marker.png',
                    map: map,
                });
                var styles = [
                    {
                        stylers: [
                            { hue: "#c5c5c5" },
                            { saturation: -100 }
                        ]
                    },
                ];
                map.setOptions({styles: styles});
                marker.setMap(map);
            }
            google.maps.event.addDomListener(window, 'load', initialize);
        </script>
        <script>
        var close = document.getElementsByClassName("closebtn");
        var i;

        for (i = 0; i < close.length; i++) {
          close[i].onclick = function(){
            var div = this.parentElement;
            div.style.opacity = "0";
            setTimeout(function(){ div.style.display = "none"; }, 600);
          }
        }
        </script>
        <!-- main JS
        ============================================ -->        
        <script src="https://undgn.id/js/main.js"></script>
        <script type="text/javascript">
        $(window).load(function() { 
          $('#preloader').delay(350).fadeOut('slow');
          $('body').css('overflow', 'visible');
        });
        </script>
    </body>
</html>
